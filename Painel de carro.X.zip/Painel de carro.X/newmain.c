#include <pic18f4520.h>
#include "config.h"
#include "atraso.h"
#include "lcd.h"
#include "adc.h"
#include "i2c.h"
#include "bits.h"
#include "pwm.h"

void itoa(unsigned int val, char* str );
void nivel_gasolina ();

void main() 
{
    
    unsigned char tmp;   
    char str[3]; //vetor que carrega a dezena e unidade da velocidade lida pelo potenci�metro.
    int x = 0;
    
    ADCON1=0x06;
    TRISA = 0xC3;
    TRISB = 0x03;
    TRISC = 0x00;
    TRISD = 0x00;
    TRISE = 0x00;
    
    //inicializando perif�ricos:
    lcd_init();
    adc_init();
    pwmInit();
    
    
    //mensagens fixas no LCD:
    lcd_cmd(L_CLR);
    lcd_cmd(L_L1);
    lcd_str("Velocidade:");
    lcd_cmd(L_L2 + 3);
    lcd_str("km/h");
   
    for (;;) 
    {
                //top-sloot: atualiza o valor enviado pelo pot1.
                tmp = (adc_amostra(0)*10)/102;
                itoa(tmp,str);
                
        switch(x) //m�quina de estado
        {
            case 0: //mostra a velocidade do carro no LCD.
            lcd_cmd(L_L2);
            lcd_dat(str[0]); //centenas.
            lcd_dat(str[1]); //dezenas.
            lcd_dat(str[2]); //unidades.  
            x = 1;
            break;
            
            case 1: //O cooler do microcontrolador simula a ventoinha do carro, e sua velocidade � proporcional a velocidade do carro, por isso ambos s�o controlados pelo mesmo potenciometro
            if(str[0] == 49)
            pwmSet(100);
            else if (str[1] == 57)
                pwmSet(90);
            else if (str[1] == 56)
                pwmSet(80);
            else if (str[1] == 55)
                pwmSet(70);
            else if (str[1] == 54)
                pwmSet(60);
            else if (str[1] == 53)
                pwmSet(50);
            else if (str[1] == 52)
                pwmSet(40);
            else if (str[1] == 51)
                pwmSet(30);
            else if (str[1] == 50)
                pwmSet(20);
            else if (str[1] == 49)
                pwmSet(10);
            else if (str[1] == 48)
                pwmSet(0);
            else 
                pwmSet(0);
            x = 2;
            break;
            
            case 2: // mostra o tanque de gasolina (apartir de leds).
            nivel_gasolina();
            x = 0;
            break;
            
            default:
            x = 0;
            break;
        }  
    }
}

//Fun��o itoa: transforma os valores lidos pelo potenciometro em valores a serem lidos pelo lcd, (0x30 � o equivalente ao 0 na ascii).
void itoa(unsigned int val, char* str)
{ 
  str[0]=((val%1000)/100)+0x30; 
  str[1]=((val%100)/10)+0x30;
  str[2]=(val%10)+0x30;
}

//Fun��o que mostra o n�vel da gasolina em forma de led.
void nivel_gasolina()
{
           
           char tanque;
           tanque = ((((adc_amostra(2)*10)/103)%100)/10) + 0x30; // 204
           if(tanque >= 57)
           {
             bitSet(PORTB,3);
             bitSet(PORTB,4);
             bitSet(PORTB,5);
             bitSet(PORTB,6);
             bitSet(PORTB,7); 
           }
           else if(tanque < 57 && tanque >= 55)
           {
             bitClr(PORTB,3);
             bitSet(PORTB,4);
             bitSet(PORTB,5);
             bitSet(PORTB,6);
             bitSet(PORTB,7);
           }
           else if(tanque < 55 && tanque >=53)
           { 
             bitClr(PORTB,3);
             bitClr(PORTB,4);
             bitSet(PORTB,5);
             bitSet(PORTB,6);
             bitSet(PORTB,7);
           }
           else if(tanque < 53 && tanque >=51)
           { 
             bitClr(PORTB,3);
             bitClr(PORTB,4);
             bitClr(PORTB,5);
             bitSet(PORTB,6);
             bitSet(PORTB,7);
           }
           else if (tanque < 51 && tanque >=49)
           {
             bitClr(PORTB,3);
             bitClr(PORTB,4);
             bitClr(PORTB,5);
             bitClr(PORTB,6);
             bitSet(PORTB,7);
           }
           else
           { 
             bitClr(PORTB,3);
             bitClr(PORTB,4);
             bitClr(PORTB,5);
             bitClr(PORTB,6);
             bitClr(PORTB,7);
           }
}
